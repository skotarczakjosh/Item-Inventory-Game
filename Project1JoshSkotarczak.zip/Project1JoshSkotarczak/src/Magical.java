public interface Magical {
    public abstract void grantWish();
    public abstract void castSpell();
}
